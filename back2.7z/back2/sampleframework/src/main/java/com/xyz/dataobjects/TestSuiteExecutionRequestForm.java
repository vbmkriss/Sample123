package com.xyz.dataobjects;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TestSuiteExecutionRequestForm {

	private String suiteName;
	private String parallel = "tests";
	private int threadPoolSize = 1;
	private Map<String, String> parameters = new HashMap<String, String>();
	private List<TestCasesExecutionRequestForm> testCases;

	public List<TestCasesExecutionRequestForm> getTestCases() {
		return testCases;
	}
	public void setTestCases(List<TestCasesExecutionRequestForm> testCases) {
		this.testCases = testCases;
	}
	public Map<String, String> getParameters() {
		return parameters;
	}
	public void setParameters(Map<String, String> parameters) {
		this.parameters = parameters;
	}
	public String getSuiteName() {
		return suiteName;
	}
	public void setSuiteName(String suiteName) {
		this.suiteName = suiteName;
	}
	public String getParallel() {
		return parallel;
	}
	public void setParallel(String parallel) {
		this.parallel = parallel;
	}
	public int getThreadPoolSize() {
		return threadPoolSize;
	}
	public void setThreadPoolSize(int threadPoolSize) {
		this.threadPoolSize = threadPoolSize;
	}
	@Override
	public String toString() {
		return "TestSuiteExecutionRequestForm [testCases=" + testCases + ", parameters=" + parameters + ", suiteName="
				+ suiteName + "]";
	}

}