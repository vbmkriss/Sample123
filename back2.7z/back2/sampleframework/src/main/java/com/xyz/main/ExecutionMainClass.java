package com.xyz.main;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import com.xyz.dataobjects.BasicTestcaseInputForm;
import com.xyz.dataobjects.TestSuiteExecutionRequestForm;
import com.xyz.exception.MandatoryParamaterMissingException;
import com.xyz.inputparser.FileBasedInputParser;
import com.xyz.inputparser.InputParserFactory;
import com.xyz.testng.TestNGExecutor;
import com.xyz.testng.TestNGUtils;
import com.xyz.updateresult.ExcelInputSheetUpdate;
import com.xyz.utils.AppConfigPropertyUtils;
import com.xyz.utils.CommonUtils;
import com.xyz.utils.EnvironmentPropertyUtils;
import com.xyz.utils.UpdateTestcaseSheet;

public class ExecutionMainClass {

	private static Logger logger = Logger.getLogger(ExecutionMainClass.class);

	private Properties config;
	private String executionId;
	private String environmentName;
	private String datasourceType;
	private String browserName;
	private String reportPath;
	private String testDataInputPath;
	//private String rerunFlag;
	private String threadCount;
	//private String remoteExecutionFlag;
	
	public static void main(String args[]) {

		ExecutionMainClass executionMainClass = null;

		try {

			//VM arguments
			//-DExecutionId=12 -DEnvironmentName=PROD -DDatasourceType=excel -DBrowserName=CHROME -DReportPath=D:\Murali\ABCD\ -DTestDataInputPath=D:\Murali\ABCD\

			executionMainClass = new ExecutionMainClass();

			if(executionMainClass.executionId == null || executionMainClass.executionId.length()==0) {
				throw new MandatoryParamaterMissingException("executionId is missing");
			}

			if(executionMainClass.environmentName == null || executionMainClass.environmentName.length()==0) {
				throw new MandatoryParamaterMissingException("environmentName is missing");
			}

			if(executionMainClass.reportPath == null || executionMainClass.reportPath.length()==0) {
				throw new MandatoryParamaterMissingException("reportPath is missing");
			}

			if(executionMainClass.testDataInputPath == null || executionMainClass.testDataInputPath.length()==0) {
				throw new MandatoryParamaterMissingException("testDataInputPath is missing");
			}

			executionMainClass.prepareConfigProperties();
	
			AppConfigPropertyUtils.setConfig(Integer.parseInt(executionMainClass.executionId), executionMainClass.config);
			logger.info("REPORT_PATH:" + AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionMainClass.executionId), "REPORT_PATH"));

			String environmentName = AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionMainClass.executionId), "ENVIRONMENT_NAME");
			logger.info("environmentName:" + environmentName);

			//Load Env Specific property file
			EnvironmentPropertyUtils.loadEnvProperties(environmentName);
			
			executionMainClass.executeSuite();
			
			logger.info("OVER OVER");

		} catch(Exception e) {

			executionMainClass.getException(e);
		}

	}

	public ExecutionMainClass() throws MandatoryParamaterMissingException {

		executionId = System.getProperty("ExecutionId");
		environmentName = System.getProperty("EnvironmentName");

		datasourceType = System.getProperty("DatasourceType", "excel");
		browserName = System.getProperty("BrowserName");

		reportPath = System.getProperty("ReportPath");
		testDataInputPath = System.getProperty("TestDataInputPath");

		threadCount = System.getProperty("ThreadCount", "1");

	}

	private void prepareConfigProperties() throws IOException {

		config = CommonUtils.getProperty("/config.properties");

		// Prepare reportpath and executionDataFolder
		if (reportPath != null) {

			config.setProperty("REPORT_PATH", reportPath + File.separator);
			logger.info("REPORT_PATH: " + config.getProperty("REPORT_PATH"));

			File reportBaseDirectory = new File(reportPath + config.getProperty("REPORTS_FOLDER"));
			if (!reportBaseDirectory.exists()) {
				reportBaseDirectory.mkdir();
			}
			config.setProperty("REPORT_PATH", reportBaseDirectory.getAbsolutePath() + File.separator);
		}

		if (testDataInputPath != null) {

			config.setProperty("TESTDATA_PATH", testDataInputPath + File.separator);
			logger.info("TESTDATA_PATH: " + config.getProperty("TESTDATA_PATH"));

			File testDataDirectory = new File(testDataInputPath + config.getProperty("TESTDATA_FOLDER"));
			if (!testDataDirectory.exists()) {
				testDataDirectory.mkdir();
			}			

			config.setProperty("TESTDATA_PATH",	testDataDirectory.getAbsolutePath() + File.separator);

			logger.info("TESTDATA_PATH: " + testDataDirectory.getAbsolutePath());
		}

		if (environmentName != null) {

			config.setProperty("ENVIRONMENT_NAME", environmentName);
			logger.info("ENVIRONMENT_NAME: " + config.getProperty("ENVIRONMENT_NAME"));

		}

		if (datasourceType != null) {

			config.setProperty("DATASOURCE_TYPE", datasourceType);
			logger.info("DATASOURCE_TYPE: " + config.getProperty("DATASOURCE_TYPE"));

		}

		if (browserName != null) {

			config.setProperty("BROWSER_TYPE", browserName);
			logger.info("BROWSER_TYPE: " + config.getProperty("BROWSER_TYPE"));

		}

		if (threadCount != null) {

			config.setProperty("THREADCOUNT", threadCount);
			logger.info("THREADCOUNT: " + config.getProperty("THREADCOUNT"));

		}

	}

	public void executeSuite() throws Exception {

		prepareConfigProperties();

		AppConfigPropertyUtils.setConfig(Integer.parseInt(executionId), config);

		logger.info("executeSuite executionId2: "+ executionId);

		logger.info("ENVIRONMENT_NAME:" + AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionId), "ENVIRONMENT_NAME"));

		logger.info("DATASOURCE_TYPE:" + AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionId), "DATASOURCE_TYPE"));

		logger.info("BROWSER_TYPE:" + AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionId), "BROWSER_TYPE"));

		logger.info("REPORT_PATH:" + AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionId), "REPORT_PATH"));

		logger.info("RERUNFLAG:" + AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionId), "RERUNFLAG"));

		logger.info("THREADCOUNT:" + AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionId), "THREADCOUNT"));

		File file = null;

		String environmentName = AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionId), "ENVIRONMENT_NAME");
		logger.info("environmentName:" + environmentName);

		//Load Env Specific property file
		EnvironmentPropertyUtils.loadEnvProperties(environmentName);

		String testDataFileLocation = AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionId), "TESTDATA_PATH");

		logger.info("TESTDATA_PATH:" + testDataFileLocation);

		String datasourceType = AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionId), "DATASOURCE_TYPE");

		boolean rerunFlag = Boolean.parseBoolean("false");

		if(datasourceType.equalsIgnoreCase("excel") || datasourceType.equalsIgnoreCase("xlsx") || datasourceType.equalsIgnoreCase("xls")) {

			file = new File(testDataFileLocation + "//Excel//Testcases.xlsx");
			File destFile = new File(AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionId), "REPORT_PATH") + "//Excel//Testcases.xlsx");
			FileUtils.copyFile(file, destFile);
			file = destFile;

		}

		environmentName = AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionId), "ENVIRONMENT_NAME");
		logger.info("environmentName:" + environmentName);

		//Load Env Specific property file
		EnvironmentPropertyUtils.loadEnvProperties(environmentName);
		
		FileBasedInputParser parser = InputParserFactory.getFileBasedInputParser(file);
		List<BasicTestcaseInputForm> forms = parser.getInputForm("Testcases");
		logger.info(forms);

		TestSuiteExecutionRequestForm suite = TestNGUtils.getSuite(forms, Integer.parseInt(executionId));
		int threadCount = Integer.parseInt(AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionId), "THREADCOUNT"));
		logger.info("threadCount:" + threadCount);
		suite.setThreadPoolSize(threadCount);

		logger.info("=== TESTNG === \n"  + suite);
		//TestNGExecutor.executeTestNG(suite);

		String filePath = "./testNG.xml";
		TestNGUtils.generateTestNGxml(forms, filePath, Integer.parseInt(executionId));

		TestNGExecutor.executeTestNG(filePath);

		//check for failure and execute
		rerunFlag = Boolean.parseBoolean(AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionId), "RERUNFLAG"));

		logger.info("Execution Main:rerunFlag" + rerunFlag);
		if(rerunFlag) {

			FileBasedInputParser rerunParser = InputParserFactory.getFileBasedInputParser(file);
			List<BasicTestcaseInputForm> rerunForms = rerunParser.getInputForm("Testcases");
			logger.info(rerunForms);

			TestSuiteExecutionRequestForm rerunSuite = TestNGUtils.rerunGetSuite(rerunForms, Integer.parseInt(executionId));
			logger.info("=== RERUN TESTNG === \n"  + rerunSuite);
			//TestNGExecutor.executeTestNG(rerunSuite);

			String rerunFilePath = "./testNG_rerun.xml";
			TestNGUtils.generateReunTestNGxml(rerunForms, rerunFilePath, Integer.parseInt(executionId));
			TestNGExecutor.executeTestNG(rerunFilePath);

		}
		
		System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
		UpdateTestcaseSheet.getExecutionSummary(new File(AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionId), "REPORT_PATH")));
		ExcelInputSheetUpdate.createAndUpdateResultExcel(new File(AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionId), "REPORT_PATH")));
		Thread.sleep(5000);
		
		int passCount = UpdateTestcaseSheet.getPassTestcaseCount(new File(AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionId), "REPORT_PATH")), "Pass");
		int failCount = UpdateTestcaseSheet.getPassTestcaseCount(new File(AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionId), "REPORT_PATH")), "Fail");
		int totalTestCaseCount = passCount + failCount;
		
		
		logger.info("totalTestCaseCount..." + totalTestCaseCount);
	
	}

	public String getException(Exception e) {

		String exceptionName = writeStackTraceToLog(e);

		logger.info("getException..." + exceptionName);

		return exceptionName;

	}

	public synchronized String writeStackTraceToLog(Exception e) {

		logger.info("writeStackTraceToLog...");

		StringWriter sw = new StringWriter();

		e.printStackTrace(new PrintWriter(sw));

		//logger.info("writeStackTraceToLog:" + sw.toString());

		return sw.toString();

	}

	public synchronized void printStackTraceToLog(Exception e) {

		logger.info("printStackTraceToLog...");

		StringWriter sw = new StringWriter();

		e.printStackTrace(new PrintWriter(sw));

		logger.info("printStackTraceToLog:" + sw.toString());

	}
	
	public static int convertMinsToMillsecs(int mins) {
		
		return (mins)*60000;
	}
}