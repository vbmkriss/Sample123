package com.xyz.driver;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.xyz.exception.InvalidBrowserException;

public class DriverPage {

	public final static String CHROME = "chrome";

	public final static String FIREFOX = "firefox";

	public final static String IE = "ie";

	public static WebDriver getDriver(String browserName) throws Exception {

			if(browserName.equalsIgnoreCase(CHROME)) {

				System.setProperty("webdriver.chrome.driver", "Drivers" + File.separator + "chromedriver.exe");

				Map<String, Object> prefs = new HashMap<String, Object>();
				prefs.put("profile.default_content_setting_values.notifications", 2);
				prefs.put("credentials_enable_service", false);
				prefs.put("profile.password_manager_enabled", false);
				ChromeOptions options = new ChromeOptions();
				options.setExperimentalOption("prefs", prefs);
				options.addArguments("start-maximized");
				options.addArguments("disable-infobars");
				options.addArguments("--disable-extensions");
				options.addArguments("--disable-notifications");
				options.setPageLoadStrategy(PageLoadStrategy.NONE);

				return new ChromeDriver(options);

			} else if(browserName.equalsIgnoreCase(FIREFOX)) {

				System.setProperty("webdriver.gecko.driver", "Drivers" + File.separator + "geckodriver.exe");

				ProfilesIni profile = new ProfilesIni();
				FirefoxProfile testprofile = profile.getProfile("TestFFProfile"); //Create Firefox profile using cmd - firefox.exe -P
				testprofile.setPreference("dom.webnotifications.enabled", false);
				testprofile.setPreference("dom.push.enabled", false);
				DesiredCapabilities dc = DesiredCapabilities.firefox();
				dc.setCapability(FirefoxDriver.PROFILE, testprofile);
				FirefoxOptions opt = new FirefoxOptions();
				opt.setPageLoadStrategy(PageLoadStrategy.NONE);
				opt.merge(dc);

				return new FirefoxDriver(opt);

			} else if(browserName.equalsIgnoreCase(IE)) {

				System.setProperty("webdriver.ie.driver", "Drivers" + File.separator + "IEDriverServer_32bit.exe");

				DesiredCapabilities ieCapabilities = DesiredCapabilities.internetExplorer();
				InternetExplorerOptions opt = new InternetExplorerOptions();
				
				opt.setCapability("nativeEvents", false);    
				opt.setCapability("unexpectedAlertBehaviour", "accept");
				opt.setCapability("ignoreProtectedModeSettings", true);
				opt.setCapability("disable-popup-blocking", true);
				opt.setCapability("enablePersistentHover", true);
				opt.merge(ieCapabilities);
				
				return new InternetExplorerDriver(opt);

			} else {

				throw new InvalidBrowserException("InvalidBrowserException:" + browserName);

			}
	}
}