package com.xyz.tests.dataobjects;

public class MyBankTestDataFields {

	private String testcaseName;
	
	private String browserName;
	
	private String userName;
	
	private String password;
	
	public String getTestcaseName() {
		return testcaseName;
	}
	public void setTestcaseName(String testcaseName) {
		this.testcaseName = testcaseName;
	}
	public String getBrowserName() {
		return browserName;
	}
	public void setBrowserName(String browserName) {
		this.browserName = browserName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "MyBankTestDataFields [testcaseName=" + testcaseName + ", browserName=" + browserName + ", userName="
				+ userName + ", password=" + password + "]";
	}
}