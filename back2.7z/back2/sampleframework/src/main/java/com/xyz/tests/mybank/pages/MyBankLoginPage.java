package com.xyz.tests.mybank.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.xyz.extentreports.MyExtentReport;
import com.xyz.seleniumapi.SeleniumFunctions;

public class MyBankLoginPage {

	WebDriver driver;

	MyExtentReport extentTest;

	By navLink = By.xpath("//*[@class='icon icon-hamburger']/../../../../div[@class='site-nav']");

	By navHome = By.xpath("//a[contains(.,'Home.')]");

	By loginButton = By.xpath("//a[@class='btn btn--default' and contains(.,'Login')]");

	By usernameTxt = By.xpath("//*[@placeholder='Customer ID ']");

	By passwordTxt = By.xpath("//*[@placeholder='Access code']");

	By signButton = By.xpath("//button[contains(.,'sign in to internet banking.')]");

	public MyBankLoginPage(WebDriver driver, MyExtentReport extentTest) {

		this.driver = driver;

		this.extentTest = extentTest;

	}

	private void waitTillPageLoads() {

		WebDriverWait wait = new WebDriverWait(driver, 240);
		wait.until(ExpectedConditions.visibilityOfElementLocated(loginButton)); 

	}

	//Set user name in textbox
	private void setUserName(String strUserName) throws Exception{

		SeleniumFunctions.input(driver, usernameTxt, strUserName, true);

	}

	//Set password in password textbox
	private void setPassword(String strPassword) throws Exception{

		SeleniumFunctions.input(driver, passwordTxt, strPassword, true);

	}

	//Click on login button
	private void clickLogin() throws Exception{

		SeleniumFunctions.click(driver, loginButton, true);

	}

	//Click on login button
	private void clickSignIn() throws Exception{

		SeleniumFunctions.click(driver, signButton, true);

	}
	
	/**

	 * This POM method will be exposed in test case to login in the application
	 * 
	 * 
	*/
	
	public void loginToME(String userName,String strPassword) throws Exception{

		waitTillPageLoads();
		
		//Click Login button
		clickLogin();  
		
		//Fill user name
		setUserName(userName);

		//Fill password
		setPassword(strPassword);

		//Click Sign In button
		clickSignIn();  
	}

}