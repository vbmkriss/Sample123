package com.xyz.inputparser;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.xyz.dataobjects.BasicTestcaseInputForm;

public class ExcelInputParser implements FileBasedInputParser {

	private File file;

	public ExcelInputParser(File file) {
		this.file = file;
	}

	public List<BasicTestcaseInputForm> getInputForm(String sheetName) throws Exception {

		List<BasicTestcaseInputForm> inputs = new ArrayList<BasicTestcaseInputForm>();

		Fillo fillo = new Fillo();
		Connection con = fillo.getConnection(file.getPath());

		//String query = "Select * from Sheet1";
		String query = "Select * from " + sheetName;
		
		Recordset recordSet = con.executeQuery(query);

		while (recordSet.next()) {

			BasicTestcaseInputForm input = new BasicTestcaseInputForm();
			input.setAppID(recordSet.getField("AppID"));
			input.setAppName(recordSet.getField("AppName"));
			input.setTestcaseId(recordSet.getField("TestcaseId"));
			input.setTestcaseName(recordSet.getField("TestcaseName"));
			input.setTestcaseDescription(recordSet.getField("TestcaseDescription"));
			input.setExecutionFlag(recordSet.getField("ExecutionFlag"));
			input.setResult(recordSet.getField("Result")); 
			
			System.out.println(input);
			inputs.add(input);

		}

		recordSet.close();
		con.close();

		return inputs;
	}
}