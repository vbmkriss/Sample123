package com.xyz.extentreports;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class ExtentManager {

	private static Logger logger = Logger.getLogger(ExtentManager.class);

	private static Map<Integer, ExtentReports> reports = new HashMap<>();

	private static Map<String, ExtentReports> reports2 = new HashMap<>();

	protected MyExtentReport myExtentTest;

	protected ExtentReports extentReports;

	protected ExtentTest extentTest;

	protected String screenshotPath;

	protected String reportPath;

	private String reportIterationPath;

	protected String reportIterationRerunPath;

	public ExtentManager() {

	}

	public static synchronized ExtentReports getExtent(int executionId, String path) {
		ExtentReports extent = reports.get(executionId);
		if (extent != null) {
			return extent; // avoid creating new instance of html file
		}
		extent = new ExtentReports();
		extent.attachReporter(getHtmlReporter(executionId, path));
		logger.info("Inside ExtentReports getExtent");
		reports.put(executionId, extent);

		return extent;
	}

	public static synchronized ExtentReports getExtent(String appName, String path) {
		logger.info("Inside ExtentReports getExtent::::::"+path);
		logger.info("Inside ExtentReports getExtent::::::"+appName);
		ExtentReports extent = reports2.get(path+File.separator+appName);
		if (extent != null) {
			return extent; // avoid creating new instance of html file
		}
		extent = new ExtentReports();
		extent.attachReporter(getHtmlReporter(appName, path));
		logger.info("Inside ExtentReports getExtent::::::"+appName);
		reports2.put(appName, extent);

		return extent;
	}

	public static String filenameDatatimeFormat() {
		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
		return dateFormat.format(date);
	}

	private static synchronized ExtentHtmlReporter getHtmlReporter(int executionId, String path) {

		ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(
				path + "Execution_"+ executionId +"_"+ "report" +  ".html");

		// make the charts visible on report open
		//htmlReporter.config().setChartVisibilityOnOpen(false);

		htmlReporter.config().setDocumentTitle("GeneSys automation test report");
		htmlReporter.config().setReportName("Regression Cycle");
		return htmlReporter;
	}

	private static synchronized ExtentHtmlReporter getHtmlReporter(String appName, String path) {

		//ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(path + "Execution-"+ appName +"-"+ "report" +  ".html");

		ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(path + appName + ".html");

		// make the charts visible on report open
		//htmlReporter.config().setChartVisibilityOnOpen(false);

		htmlReporter.config().setDocumentTitle("Test automation test report");
		htmlReporter.config().setReportName("Regression Cycle");
		return htmlReporter;
	}

	public static synchronized ExtentTest createTest(int executionId, String name, String description) {
		ExtentReports extent = reports.get(executionId);
		return extent.createTest(name, description);
	}

	public MyExtentReport startReport(String reportPath, String executionID, String appName, String testcaseID, int iterationCount, String rerun, String htmlReportName, String testcaseName, String testCaseDescription, int errorFlag) throws Exception {

		logger.info("startReport..." + "testcaseName:" + testcaseName + " iterationCount:" + iterationCount);

		/*if (Integer.parseInt(rerun) >0) {

			createRerunReport(errorFlag, appName, testcaseID, rerun, iterationCount, testCaseDescription);

		}else{

			setReportDirectory(appName, testcaseID, iterationCount, Integer.parseInt(rerun));
			createReport(htmlReportName, testcaseName, testCaseDescription);

		}*/

		//setReportDirectory(reportPath, appName, testcaseName, iterationCount, Integer.parseInt(rerun));
		setReportDirectory(reportPath, executionID, appName, testcaseName, iterationCount, 0);
		createReport(htmlReportName, testcaseName, testCaseDescription);

		myExtentTest.log(Status.INFO, "Execution Starts");

		return myExtentTest;
	}

	public void setReportDirectory(String reportPath, String executionID, String appName, String testcaseName, int iterationNumber, int rerun) throws IOException {

		logger.info("executionId:"+appName);

		setReportIterationPath(createFolder(reportPath, executionID, appName, testcaseName, iterationNumber));

		logger.info("setReportDirectory->reportIterationPath:" + getReportIterationPath());
		logger.info("rerun: "+rerun);

		if (rerun > 0) {
			reportIterationRerunPath = getReportIterationPath() + File.separator + "-" + rerun;
			File rerunFile = new File(reportIterationRerunPath);
			if (!rerunFile.exists()) {
				rerunFile.mkdir();
			}
			setReportIterationPath(reportIterationRerunPath);
		}


		logger.info("screenshotPath:::" + screenshotPath);

		screenshotPath = getReportIterationPath() + File.separator + "IMAGES" + File.separator;

		File screenshotPathFolder = new File(screenshotPath);
		if (!screenshotPathFolder.exists()) {
			screenshotPathFolder.mkdir();
		}

		logger.info("screenshotPath:::" + screenshotPath);
	}

	public String createFolder(String filePath, String appName, String testcaseName) {

		File fileDir;

		File reportExecutionIdFolder = new File(filePath + appName);
		if (!reportExecutionIdFolder.exists()) {
			reportExecutionIdFolder.mkdir();
		}
		logger.info("reportExecutionIdFolder"+ reportExecutionIdFolder.getPath());

		File reportAppIdFolder = new File(reportExecutionIdFolder.getPath() + File.separator + testcaseName);
		if (!reportAppIdFolder.exists()) {
			reportAppIdFolder.mkdir();
		}
		fileDir = reportAppIdFolder;
		logger.info("reportExecutionIdFolder"+ reportExecutionIdFolder.getPath());

		return fileDir.getPath();
	}

	public String createFolder(String filePath, String executionID, String appName, String testcaseName, int iterationCount) throws NumberFormatException, IOException {

		File fileDir;

		File reportFolder = new File(filePath);
		if (!reportFolder.exists()) {
			reportFolder.mkdir();
		}
		logger.info("reportFolder"+ reportFolder.getPath());
		
		File reportexecutionIDFolder = new File(reportFolder.getPath() + File.separator + executionID);
		if (!reportexecutionIDFolder.exists()) {
			reportexecutionIDFolder.mkdir();
		}
		fileDir = reportexecutionIDFolder;
		logger.info("reportexecutionIDFolder"+ reportexecutionIDFolder.getPath());
		
		File reportAppIdFolder = new File(reportexecutionIDFolder.getPath() + File.separator + appName);
		if (!reportAppIdFolder.exists()) {
			reportAppIdFolder.mkdir();
		}
		fileDir = reportAppIdFolder;
		logger.info("reportAppIdFolder"+ reportAppIdFolder.getPath());

		if (!testcaseName.isEmpty()) {
			File reportScenarioIdFolder = new File(reportAppIdFolder.getPath() + File.separator + testcaseName);
			if (!reportScenarioIdFolder.exists()) {
				reportScenarioIdFolder.mkdir();
			}
			logger.info("reportScenarioIdFolder" + reportScenarioIdFolder.getPath());

			File reportIterationCountFolder = new File(
					reportScenarioIdFolder.getPath() + File.separator + String.valueOf(iterationCount));
			if (!reportIterationCountFolder.exists()) {
				reportIterationCountFolder.mkdir();
			}
			logger.info("reportIterationCountFolder" + reportIterationCountFolder.getPath());
			fileDir = reportIterationCountFolder;
		}

		return fileDir.getPath();
	}

	protected void createReport(String reportName, String testcaseName, String testDescription) throws IOException {

		logger.info("Tomato Base : reportName: ====="+ reportName);
		extentReports = ExtentManager.getExtent(reportName.toLowerCase(), getReportIterationPath()+File.separator);
		myExtentTest = new MyExtentReport(extentReports, testcaseName.toLowerCase(), testDescription.toLowerCase());
	}

	public void setReportDirectory(String appName, String testcaseName) throws IOException {

		logger.info("executionId:"+appName);

		setReportIterationPath(createFolder(reportPath, appName, testcaseName));
		logger.info("setReportDirectory->reportIterationPath:" + getReportIterationPath());

		logger.info("screenshotPath:::" + screenshotPath);

		screenshotPath = getReportIterationPath() + File.separator + "IMAGES" + File.separator;

		File screenshotPathFolder = new File(screenshotPath);
		if (!screenshotPathFolder.exists()) {
			screenshotPathFolder.mkdir();
		}

		logger.info("screenshotPath:::" + screenshotPath);
	}

	public synchronized String writeStackTraceToLog(Exception e) {

		logger.info("writeStackTraceToLog...");

		StringWriter sw = new StringWriter();

		e.printStackTrace(new PrintWriter(sw));

		//logger.info("writeStackTraceToLog:" + sw.toString());

		return sw.toString();

	}

	public synchronized void printStackTraceToLog(Exception e) {

		logger.info("printStackTraceToLog...");

		StringWriter sw = new StringWriter();

		e.printStackTrace(new PrintWriter(sw));

		logger.info("printStackTraceToLog:" + sw.toString());

	}

	public String getException(MyExtentReport myExtentTest, Exception e) {

		logger.info("getException...");

		String exceptionName = writeStackTraceToLog(e);

		String errReason = e.getMessage();

		try {

			//TakeScreenshotUpdateReport(apiResult, screenshotPath, "Click here to see Error occured", "Click here to see Error occured");

		} catch (Exception e1) {

			writeStackTraceToLog(e1);

		}

		logger.info("getException...exceptionName::" + exceptionName);

		myExtentTest.log(Status.FAIL, "Test Case failed due to "+ errReason);

		return exceptionName;

	}

	public String getReportIterationPath() {
		return reportIterationPath;
	}

	public void setReportIterationPath(String reportIterationPath) {
		this.reportIterationPath = reportIterationPath;
	}
}