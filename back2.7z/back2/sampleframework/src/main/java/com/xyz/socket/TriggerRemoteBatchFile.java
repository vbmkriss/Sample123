package com.xyz.socket;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;

public class TriggerRemoteBatchFile {

	public static void main(String[] args) throws IOException, InterruptedException {
		
		//Powershell script execution //Set-ExecutionPolicy RemoteSigned 
		//create batch file to execute powershellscript 
		//Powershell.exe -executionpolicy remotesigned -File  C:\Users\edepadmin\Desktop\samplepowershell.ps1
		//String[] input = { "C:/Users/edepadmin/Desktop/executepowershellscript.bat" };
		
		//Batch Script Execution
		String[] input = { "C:/Users/edepadmin/Desktop/Sample1.bat" };
		
		//Shell Script Execution
		//String[] input = { "/home/automation1/selenium/temp/sampleshellscript.sh" };
		
		TriggerRemoteBatchFile tt = new TriggerRemoteBatchFile();
		tt.trigger(input, 1);
		stopAll();
	}

	private void trigger(String[] input, int id) throws IOException, InterruptedException {
		String parms = "";
		parms = parms + "[";
		for (String data : input) {
			parms = parms + "\"" + data + "\",";
		}
		if (input.length > 0) {
			parms = parms.substring(0, parms.length() - 1);
		}
		parms = parms + "]";
		String inputArg = "{\"id\":" + id + ",\"input\":" + parms + "}";
		System.out.println("===" + inputArg);
		URL obj = new URL("http://10.20.40.168:8091/ScriptTrigger/trigger");
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		con.setRequestMethod("POST");
		con.setRequestProperty("Content-Type", "application/json");

		// For POST only - START
		con.setDoOutput(true);
		OutputStream os = con.getOutputStream();
		os.write(inputArg.getBytes());
		os.flush();
		os.close();
		
		// For POST only - END
		int responseCode = con.getResponseCode();
		
		System.out.println("POST Response Code :: " + responseCode);
		
		if (responseCode == HttpURLConnection.HTTP_OK) { // success
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			// print result
			System.out.println("output from cmd:" + response.toString());
			temp();
			
		} else {
			System.out.println("POST request not worked");
		}
	}

	public void temp() throws UnknownHostException, IOException {
		
		String sentence;
        String modifiedSentence;

        BufferedReader inFromUser =
          new BufferedReader(new InputStreamReader(System.in));

        Socket clientSocket = new Socket("10.20.40.168", 8091);

        DataOutputStream outToServer =
          new DataOutputStream(clientSocket.getOutputStream());

        BufferedReader inFromServer =
          new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

        sentence = inFromUser.readLine();

        outToServer.writeBytes(sentence + '\n');

        modifiedSentence = inFromServer.readLine();

        System.out.println("FROM SERVER: " + modifiedSentence);

        clientSocket.close();
		
		
	}
	
	private static void stopAll() throws IOException {
		URL obj = new URL("http://10.20.40.168:8091/ScriptTrigger/stopAll");
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		con.setRequestMethod("GET");
		int responseCode = con.getResponseCode();
		System.out.println("GET Response Code :: " + responseCode);
		if (responseCode == HttpURLConnection.HTTP_OK) { // success
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			// print result
			System.out.println(response.toString());
		} else {
			System.out.println("GET request not worked");
		}
	}
}