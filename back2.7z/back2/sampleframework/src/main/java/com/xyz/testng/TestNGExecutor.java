package com.xyz.testng;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

import com.xyz.dataobjects.TestCasesExecutionRequestForm;
import com.xyz.dataobjects.TestSuiteExecutionRequestForm;

public class TestNGExecutor {

	private static Logger log = Logger.getLogger(TestNGExecutor.class);

	public static void executeTestNG(TestSuiteExecutionRequestForm form) {

		log.info("Testing Started");

		TestNG testNG = new TestNG();
		List<XmlSuite> suites = new ArrayList<XmlSuite>();

		suites.add(createSuite(form));
		
		testNG.setParallel(XmlSuite.ParallelMode.TESTS); //testNG.setParallel(form.getParallel());
		
		log.info("getThreadPoolSize():" + form.getThreadPoolSize());
		testNG.setSuiteThreadPoolSize(form.getThreadPoolSize());

		testNG.setXmlSuites(suites);
		testNG.setUseDefaultListeners(false);
		testNG.run();

		log.info("Testing Ended");
	}

	public static void executeTestNG(String filename) {

		log.info("Testing Started");

		List<String> file = new ArrayList<String>();
		file.add(filename);
		TestNG testNG = new TestNG();
		testNG.setUseDefaultListeners(false);
		testNG.setTestSuites(file);
		testNG.run();

		log.info("Testing Ended");

	}

	private static XmlSuite createSuite(TestSuiteExecutionRequestForm form) {

		XmlSuite suite = new XmlSuite();

		suite.setName(form.getSuiteName());

		// suite.addListener(arg0);

		// Prepare Suite parameters
		LinkedHashMap<String, String> suiteParams = new LinkedHashMap<String, String>();
		for (Map.Entry<String, String> param : form.getParameters().entrySet()) {
			suiteParams.put(param.getKey(), param.getValue());
			
			System.out.println("======param.getKey(), param.getValue()" + param.getKey() + "=>" + param.getValue());
		}
		suite.setParameters(suiteParams);
		System.out.println("======param.getKey(), param.getValue()" + suiteParams.size());

		List<XmlTest> tests = new ArrayList<XmlTest>();
		for (TestCasesExecutionRequestForm testList : form.getTestCases()) {
			
			XmlTest test = new XmlTest(suite);

			// Prepare Test parameters
			Map<String, String> parameters = testList.getParameters();
			for (Map.Entry<String, String> param : parameters.entrySet()) {
				test.addParameter(param.getKey(), param.getValue());
			}

			// Prepare TestClasses
			List<XmlClass> clazzes = new ArrayList<XmlClass>();
			for (String testClass : testList.getTestClasses()) {
				clazzes.add(new XmlClass(testClass));
			}
			
			test.setClasses(clazzes);
			test.setName(testList.getTestName());
			tests.add(test);
		}
		suite.setTests(tests);

		return suite;
	}
}