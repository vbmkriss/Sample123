package com.xyz.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import com.fasterxml.jackson.databind.ObjectMapper;

public class CommonUtils {


	//All the methods in this class should be static

	public static String getExtensionOfFile(File file) {

		String fileExtension="";

		// Get file Name first
		String fileName=file.getName();

		// If fileName do not contain "." or starts with "." then it is not a valid file
		if(fileName.contains(".") && fileName.lastIndexOf(".")!= 0){

			fileExtension=fileName.substring(fileName.lastIndexOf(".")+1);

		}

		return fileExtension;
	}

	/*public static synchronized Properties loadConfigProperties(String path) throws IOException {
		Properties prop = new Properties();
		prop.load(CommonUtils.class.getResourceAsStream(path));
		return prop;
	}*/

	public static synchronized Properties getProperty(String path) throws IOException {
		Properties prop = new Properties();
		prop.load(CommonUtils.class.getResourceAsStream(path));
		return prop;
	}

	public static Map<String, String> getObjectToMap(Object obj){

		ObjectMapper oMapper = new ObjectMapper();

		// object -> Map
		@SuppressWarnings("unchecked")
		Map<String, Object> map = oMapper.convertValue(obj, Map.class);

		//System.out.println(map);

		Map<String, String> result = new HashMap<>();

		for(Map.Entry<String, Object> m : map.entrySet()) {

			result.put(m.getKey(), String.valueOf(m.getValue()));
		}
		return result;
	}

	public static void newFileWatcher(String filePath) throws IOException, InterruptedException {

		WatchService watchService = FileSystems.getDefault().newWatchService();

		System.out.println("****" + System.getProperty("user.home"));

		Path path = Paths.get(filePath);

		path.register(
				watchService, 
				StandardWatchEventKinds.ENTRY_CREATE 
				//,StandardWatchEventKinds.ENTRY_DELETE 
				//,StandardWatchEventKinds.ENTRY_MODIFY
				);

		WatchKey key;

		while ((key = watchService.take()) != null) {
			for (WatchEvent<?> event : key.pollEvents()) {
				System.out.println(
						"Event kind:" + event.kind() 
						+ ". File affected: " + event.context() + ".");
			}
			key.reset();
		}
	}

	public String readFile(String fileName) throws IOException {

		BufferedReader br = new BufferedReader(new FileReader(fileName));
		try {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append("\n");
				line = br.readLine();
			}
			return sb.toString();
		} finally {
			br.close();
		}
	}
}