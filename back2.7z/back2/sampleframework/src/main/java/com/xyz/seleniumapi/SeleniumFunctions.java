package com.xyz.seleniumapi;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;
import com.xyz.extentreports.MyExtentReport;

public class SeleniumFunctions {

	private static Logger logger = Logger.getLogger(SeleniumFunctions.class);
	
	public static void input(WebDriver driver, By obj,String data, boolean highlightFlag) throws Exception{
		if(highlightFlag) {
			highlightElement(driver, obj);
		}
		driver.findElement(obj).sendKeys(data);
	}

	public static String getText(WebDriver driver , By obj, boolean highlightFlag)  throws Exception{
		if(highlightFlag) {
			highlightElement(driver, obj);
		}
		return driver.findElement(obj).getText();
	}

	public static void click(WebDriver driver , By obj, boolean highlightFlag)  throws Exception{
		if(highlightFlag) {
			highlightElement(driver, obj);
		}
		driver.findElement(obj).click();
	}

	public static void click(WebDriver driver, By by, MyExtentReport extentTest) {
	    try {
	        (new WebDriverWait(driver, 10)).until(ExpectedConditions.elementToBeClickable(by));
	        driver.findElement(by).click();
	        extentTest.log(Status.PASS, "Element identified by " + by.toString() + " was clicked");
	    } catch (StaleElementReferenceException sere) {
	        driver.findElement(by).click();
	    } catch (TimeoutException toe) {
	    	extentTest.log(Status.FAIL, "Element identified by " + by.toString() + " was not clickable after 10 seconds");
	    }
	}
	    
	public static void elementRemoveHighlight(WebDriver driver, WebElement element){
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute('style', arguments[1]);",element, "");
	}

	public static void elementHighlight(WebDriver driver, WebElement element){
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute('style', arguments[1]);",element, "color: red; border: 3px solid red;");
	}

	public static void scrollingToBottomofAPage(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
	}

	public static void scrollingToTopofAPage(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0, -document.body.scrollHeight);");
	}

	public static void scrollingToElementofAPage(WebDriver driver, WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", element);
	}

	public static boolean isElementPresent(WebDriver driver , By obj){  
		boolean elementPresentFlag = false;
		try {    
			if(driver.findElement(obj).isDisplayed()){      
				elementPresentFlag = true;
			}else{
				elementPresentFlag = false;
			}
		}catch(Exception e){       
			elementPresentFlag = false;
		}
		return elementPresentFlag; 
	}

	//Highlighting the current object
	public static void highlightElement(WebDriver driver, By obj){
		try {
			
			if(isElementPresent(driver, obj)){
				elementHighlight(driver, driver.findElement(obj));
				Thread.sleep(250);
				elementRemoveHighlight(driver, driver.findElement(obj));
			} 
		} catch (Exception e) {
			logger.info(e.getStackTrace());
		}
	}

	public static void Hover(WebDriver driver, WebElement element) {
		
		Actions action = new Actions(driver);
		action.moveToElement(element).perform();
	
	}
	
	public static void HoverAndClick(WebDriver driver, WebElement elementToHover, WebElement elementToClick) {
	
		Actions action = new Actions(driver);
		action.moveToElement(elementToHover).click(elementToClick).build().perform();

	}
	
	//Take screenshot & Copy to existing report path
	public static String captureScreenshot(WebDriver driver, String reportpath, String executionID, String appName, String currentTest, String iterationNumber) throws IOException {

		String tempPath = "";
		String imageName;
		Calendar cal = new GregorianCalendar();
		int month = cal.get(Calendar.MONTH);
		int year = cal.get(Calendar.YEAR);
		int sec = cal.get(Calendar.SECOND);
		int min = cal.get(Calendar.MINUTE);
		int date = cal.get(Calendar.DATE);
		int day = cal.get(Calendar.HOUR_OF_DAY);

		tempPath = reportpath;

		String imageFileName = currentTest + year + "_" + date + "_" + (month + 1) + "_" + day + "_" + min + "_" + sec;
		imageName = tempPath + File.separator + executionID + File.separator + appName + File.separator + currentTest + File.separator + iterationNumber + File.separator + "IMAGES"  + File.separator + imageFileName;

		//Convert web driver object to TakeScreenshot
		TakesScreenshot scrShot =((TakesScreenshot)driver);

		//Call getScreenshotAs method to create image file
		File srcFile=scrShot.getScreenshotAs(OutputType.FILE);

		//Move image file to new destination
		FileUtils.copyFile(srcFile, new File(imageName + ".png"));

		return "IMAGES" + File.separator + imageFileName + ".png";

	}
}