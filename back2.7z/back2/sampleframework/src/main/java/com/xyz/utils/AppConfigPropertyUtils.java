package com.xyz.utils;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

public class AppConfigPropertyUtils {
	private static Logger logger = Logger.getLogger(AppConfigPropertyUtils.class);
	private static Map<Integer, Properties> properties = new HashMap<>();
	
	public static synchronized Properties getConfig(int executionId) {
		return properties.get(executionId);		
	}
	
	private AppConfigPropertyUtils() {
		
	}
	
	public static synchronized void setConfig(int executionId, Properties prop) {
		logger.info("setConfig: " + executionId + ":"+ prop);
		properties.put(executionId, prop);		
	}
	
	public static synchronized String getPropertyValueFromConfig(int executionId, String keyName) throws IOException {
		Properties utilConfig = AppConfigPropertyUtils.getConfig(executionId);
		return utilConfig.getProperty(keyName);
	}

	public static synchronized void setPropertyValueToConfig(int executionId, String keyName, String value) throws IOException {
		Properties utilConfig = AppConfigPropertyUtils.getConfig(executionId);
		utilConfig.setProperty(keyName, value);
		setConfig(executionId, utilConfig);
	}
}