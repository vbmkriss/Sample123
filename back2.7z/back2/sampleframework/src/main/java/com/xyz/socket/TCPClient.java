package com.xyz.socket;

import java.io.*;
import java.net.*;

class TCPClient {

    public static void main(String argv[]) throws Exception {
    	
    	String sentence;
        
    	String modifiedSentence;

    	//http://www.javasavvy.com/execute-shell-script-java-using-process-builder/
    	
        String batchScript = "executepowershellscript.bat";
    	
    	//String batchScript = "/home/automation1/selenium/temp/sampleshellscript.sh";

        Reader inputString = new StringReader(batchScript);
        
        BufferedReader inFromUser =  new BufferedReader(inputString);

        Socket clientSocket = new Socket("10.20.40.168", 6789);

        DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());

        BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

        sentence = inFromUser.readLine();
        
        outToServer.writeBytes(sentence + '\n');

        modifiedSentence = inFromServer.readLine();

        System.out.println("FROM SERVER: " + modifiedSentence);

        clientSocket.close();
                  
    }
}