package com.xyz.utils;

import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;

public class EnvironmentPropertyUtils {
	
	private static Logger logger = Logger.getLogger(EnvironmentPropertyUtils.class);
	
	public static Properties envProp;
	
	public static synchronized Properties loadEnvProperties(String envName) throws IOException {
		
		logger.info("envName:" + envName);
		
		envProp = new Properties();
		
		if(envName.equalsIgnoreCase("dev")) {
			
			envProp.load(EnvironmentPropertyUtils.class.getResourceAsStream("/env_dev.properties"));
			
		} else if(envName.equalsIgnoreCase("prod")) {
			
			envProp.load(EnvironmentPropertyUtils.class.getResourceAsStream("/env_prod.properties"));
			
		} 
		return envProp;
	}
}