package com.xyz.tests.dataobjects;

import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.xyz.exception.InvalidFileFormatException;
import com.xyz.utils.CommonUtils;

public class ReadTestDataStoreInList {


	public ArrayList<MyBankTestDataFields> getMyBankAppDataAsList(File file, String sheetName, String testcaseName) throws FilloException, InvalidFileFormatException, SQLException, ClassNotFoundException {

		String fileExtention = CommonUtils.getExtensionOfFile(file);

		ArrayList<MyBankTestDataFields> orderTestDataList;

		if(fileExtention.equalsIgnoreCase("xls") || fileExtention.equalsIgnoreCase("xlsx")) {

			orderTestDataList = new ArrayList<>();

			//Now you can set table start row and column
			System.setProperty("ROW", "1");

			Fillo fillo=new Fillo();

			Connection connection = fillo.getConnection(file.getPath());

			String strQuery="Select * from " + sheetName + " where TestcaseName='" + testcaseName + "'";

			Recordset recordset=connection.executeQuery(strQuery);

			while(recordset.next()){

				MyBankTestDataFields testData = new MyBankTestDataFields();

				testData.setTestcaseName(recordset.getField("TestcaseName"));
				testData.setBrowserName(recordset.getField("BrowserName"));
				testData.setUserName(recordset.getField("UserName"));
				testData.setPassword(recordset.getField("Password"));

				orderTestDataList.add(testData);
			}

			recordset.close();
			connection.close();

			Iterator<MyBankTestDataFields> it = orderTestDataList.iterator(); 

			while (it.hasNext()) { 
				System.out.println(it.next() + " ");
			}

			return orderTestDataList;

		} else {

			throw new InvalidFileFormatException("File format incorrect:" + fileExtention);
		}
	}

}