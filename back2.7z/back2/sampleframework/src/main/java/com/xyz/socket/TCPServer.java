package com.xyz.socket;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.Executors;

public class TCPServer {

	public static void main(String argv[]) throws Exception {

		String clientSentence;

		String capitalizedSentence;
		
		String fileOutput;

		ServerSocket welcomeSocket = new ServerSocket(6789);

		while(true) {

			Socket connectionSocket = welcomeSocket.accept();

			BufferedReader inFromClient =   new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));

			DataOutputStream  outToClient =  new DataOutputStream(connectionSocket.getOutputStream());

			clientSentence = inFromClient.readLine();

			System.out.println("clientSentence:" + clientSentence);

			ProcessBuilder pb = new ProcessBuilder();

			String osName = System.getProperty("os.name");

			if(osName.toLowerCase().contains("windows")) {

				if(clientSentence.contains("executepowershellscript.bat")) {
					clientSentence = "C:/Users/edepadmin/Desktop/" + clientSentence;
				}

				pb.command("cmd.exe","/C","Start",clientSentence, "C:/Users/edepadmin/Desktop/myoutput2.txt");

				Process p = pb.start();

				StreamGobbler streamGobbler = new StreamGobbler(p.getInputStream(), System.out::println);
				Executors.newSingleThreadExecutor().submit(streamGobbler);
				int exitCode = p.waitFor();
				p.exitValue();
				System.out.println("exitCode:" + exitCode);


			} else {

				System.out.println("Inside linux");

				pb.command("sh", "-c", clientSentence);

				//pb.directory(new File(System.getProperty("user.home")));

				Process process = pb.start();

				StreamGobbler streamGobbler = new StreamGobbler(process.getInputStream(), System.out::println);

				Executors.newSingleThreadExecutor().submit(streamGobbler);

				int exitCode = process.waitFor();

				System.out.println("exitCode:" + exitCode);

			}
			
			/*capitalizedSentence = clientSentence.toUpperCase() + '\n';
			outToClient.writeBytes(capitalizedSentence);*/
			
			Thread.sleep(5000);
			
			String output = readFile("C:/Users/edepadmin/Desktop/myoutput2.txt");
			Thread.sleep(5000);
			fileOutput = output;
			
			capitalizedSentence =   fileOutput + '\n';
			
			outToClient.writeBytes(capitalizedSentence);
			System.out.println("OVER OVER");

		}
	}

	public static String readFile(String fileName) throws IOException {

		BufferedReader br = new BufferedReader(new FileReader(fileName));
		StringBuilder sb = null;
		String line;
		try {
			sb = new StringBuilder();

			while ((line = br.readLine()) != null) {
				System.out.println("inside");
				sb.append(line);
				line = br.readLine();
			}
			
		} catch(Exception e){ 
			e.printStackTrace();
		}finally {
			br.close();
			return sb.toString();
			
		}
	}
}