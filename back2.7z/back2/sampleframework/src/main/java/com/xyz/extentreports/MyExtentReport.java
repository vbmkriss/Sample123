package com.xyz.extentreports;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityModelProvider;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.Markup;

public class MyExtentReport {
	
	ExtentTest extentTest;
	ExtentReports extentReports;

	public MyExtentReport(ExtentReports extentReports, String testName, String description){
		this.extentReports = extentReports;
		extentTest = extentReports.createTest(testName,description);
		this.extentReports.flush();
	}
	
	public void log(Status status, String details){
		extentTest.log(status, details);
		extentReports.flush();
	}

	public void log(Status fail, String failMessage, MediaEntityModelProvider build) {
		extentTest.log(fail, failMessage, build);
		extentReports.flush();
	}

	public void addLabellog(Status info, Markup createLabel) {
		extentTest.log(info, createLabel);
		extentReports.flush();
		
	}
}