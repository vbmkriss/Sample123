package com.xyz.dataobjects;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TestCasesExecutionRequestForm {
	private String testName;
	private List<String> testClasses=new ArrayList<String>();
	private Map<String, String> parameters = new HashMap<String, String>();	
	
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public List<String> getTestClasses() {
		return testClasses;
	}
	public void setTestClasses(List<String> testClasses) {
		this.testClasses = testClasses;
	}
	public Map<String, String> getParameters() {
		return parameters;
	}	
	public void setParameters(Map<String, String> parameters) {
		this.parameters = parameters;
	}
	@Override
	public String toString() {
		return "TestCasesExecutionRequestForm [testName=" + testName + ", testClasses=" + testClasses + ", parameters="
				+ parameters + "]";
	}

}