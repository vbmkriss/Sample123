package com.xyz.utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReadFileAndStoreInString {

	public static void main(String args[]) throws IOException {

		ReadFileAndStoreInString rr = new ReadFileAndStoreInString();
		String output = rr.readFile("C:\\Users\\muralikrishnanb\\Desktop\\myoutput2.txt");
		System.out.println("====" + output);
		
	}

	public String readFile(String fileName) throws IOException {
		
		BufferedReader br = new BufferedReader(new FileReader(fileName));
		try {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append("\n");
				line = br.readLine();
			}
			return sb.toString();
		} finally {
			br.close();
		}
	}
}
