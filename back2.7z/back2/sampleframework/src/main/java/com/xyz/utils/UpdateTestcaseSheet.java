package com.xyz.utils;

import java.io.File;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.apache.log4j.Logger;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

public class UpdateTestcaseSheet {

	private static Logger logger = Logger.getLogger(UpdateTestcaseSheet.class);

	public static final String ISO_8601_24H_FULL_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS";

	public static final String DATE_TIME_ZONE = "EST";

	public static void resetExecutionFlag(String reportFolderPath) throws FilloException {

		Fillo fillo2 = new Fillo();

		Connection connection2 = fillo2.getConnection(reportFolderPath + File.separator + "Excel" + File.separator + "Testcases.xlsx");

		String query2 = "Select * from " + "testcases";

		Recordset recordSet2 = connection2.executeQuery(query2);

		while (recordSet2.next()) {

			String strQuery="Update "+  "testcases" + " Set ExecutionFlag='N'";

			connection2.executeUpdate(strQuery);
		}
		connection2.close();
	}

	public static String getDateDifference(String dateAsString) throws ParseException, InterruptedException {

		SimpleDateFormat sdf = new SimpleDateFormat(ISO_8601_24H_FULL_FORMAT);

		sdf.setTimeZone(TimeZone.getTimeZone(DATE_TIME_ZONE));

		logger.info("sdf.format(BEGINNING_OF_TIME) = " + sdf.parse(dateAsString).getTime());

		Date finalResult = sdf.parse(dateAsString);

		Date today = new Date();

		String currentDateTime = sdf.format(today);
		logger.info("currentDateTime:" + currentDateTime);

		logger.info("sdf.format(END_OF_TIME) = " + sdf.parse(currentDateTime).getTime());

		long diff = sdf.parse(currentDateTime).getTime() - finalResult.getTime();

		DecimalFormat crunchifyFormatter = new DecimalFormat("######");
		int diffmin = (int) (diff / (60 * 1000));
		logger.info("difference between minutues: " + crunchifyFormatter.format(diffmin));

		int diffsec = (int) (diff / (1000));
		logger.info("difference between seconds: " + crunchifyFormatter.format(diffsec));

		logger.info("difference between milliseconds: " + crunchifyFormatter.format(diff));

		return crunchifyFormatter.format(diffmin);
	}

	public static void getExecutionSummary(File reportFileExcelPath) {

		logger.info("getExecutionSummary:::::::::::::" + reportFileExcelPath);

		int passCount = getPassTestcaseCount(reportFileExcelPath, "Pass");

		int failCount = getPassTestcaseCount(reportFileExcelPath, "Fail");

		int totalTestCaseCount = passCount + failCount;

		logger.info("Total Test cases:" + totalTestCaseCount);

		logger.info("Passed Test cases:" + passCount );

		logger.info("Failed Test cases:" + failCount );

	}

	public static int getPassTestcaseCount(File reportFileExcelPath, String testcaseResultStatus) {

		int passCount = 0;

		Fillo fillo;

		Connection connection = null;

		Recordset recordSet = null;

		try {

			fillo = new Fillo();

			//connection = fillo.getConnection(reportFileExcelPath + File.separator + "Testcases.xlsx");
			connection = fillo.getConnection(reportFileExcelPath.getPath()  + File.separator + "Excel" + File.separator + "Testcases.xlsx");

			String query = "Select * from testcases where ExecutionFlag = 'Y' and Result='" + testcaseResultStatus +"'";
			logger.info("query:" + query);

			recordSet = connection.executeQuery(query);

			while (recordSet.next()) {

				passCount = passCount + 1;

			}

		} catch(Exception e) {


		} finally {

			if(connection != null) {

				connection.close();

			}

			if(recordSet != null) {

				recordSet.close();

			}

		}

		return passCount;

	}

}