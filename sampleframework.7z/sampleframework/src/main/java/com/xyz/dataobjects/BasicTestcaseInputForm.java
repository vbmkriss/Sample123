package com.xyz.dataobjects;

public class BasicTestcaseInputForm {

	private int executionID;
	private String appID;
	private String appName;
	private String testcaseId;
	private String testcaseName;
	private String testcaseDescription;
	private String executionFlag;
	private String result;
	private String rerunFlag;
	
	public String getAppID() {
		return appID;
	}
	public void setAppID(String appID) {
		this.appID = appID;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getTestcaseId() {
		return testcaseId;
	}
	public void setTestcaseId(String testcaseId) {
		this.testcaseId = testcaseId;
	}
	public String getTestcaseName() {
		return testcaseName;
	}
	public void setTestcaseName(String testcaseName) {
		this.testcaseName = testcaseName;
	}
	public String getTestcaseDescription() {
		return testcaseDescription;
	}
	public void setTestcaseDescription(String testcaseDescription) {
		this.testcaseDescription = testcaseDescription;
	}
	public String getExecutionFlag() {
		return executionFlag;
	}
	public void setExecutionFlag(String executionFlag) {
		this.executionFlag = executionFlag;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getRerunFlag() {
		return rerunFlag;
	}
	public void setRerunFlag(String rerunFlag) {
		this.rerunFlag = rerunFlag;
	}
	public int getExecutionID() {
		return executionID;
	}
	public void setExecutionID(int executionID) {
		this.executionID = executionID;
	}
	@Override
	public String toString() {
		return "BasicTestcaseInputForm [executionID=" + executionID + ", appID=" + appID + ", appName=" + appName
				+ ", testcaseId=" + testcaseId + ", testcaseName=" + testcaseName + ", testcaseDescription="
				+ testcaseDescription + ", executionFlag=" + executionFlag + ", result=" + result + ", rerunFlag="
				+ rerunFlag + "]";
	}
}