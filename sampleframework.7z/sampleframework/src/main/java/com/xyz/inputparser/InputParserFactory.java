package com.xyz.inputparser;

import java.io.File;

import com.xyz.exception.InvalidFileFormatException;
import com.xyz.utils.CommonUtils;

public class InputParserFactory {


	public static FileBasedInputParser getFileBasedInputParser(File file) throws InvalidFileFormatException {

		String fileExtention = CommonUtils.getExtensionOfFile(file);

		if(fileExtention.equalsIgnoreCase("xls") || fileExtention.equalsIgnoreCase("xlsx")) {

			return new ExcelInputParser(file);

		} else {

			throw new InvalidFileFormatException("File format incorrect:" + fileExtention);
		}
	}
}