package com.xyz.inputparser;

import java.util.List;

import com.xyz.dataobjects.BasicTestcaseInputForm;

public interface FileBasedInputParser {
	List<BasicTestcaseInputForm> getInputForm(String sheetName) throws Exception;
}
