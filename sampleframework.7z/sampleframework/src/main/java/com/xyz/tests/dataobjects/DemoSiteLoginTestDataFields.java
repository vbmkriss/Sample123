package com.xyz.tests.dataobjects;

public class DemoSiteLoginTestDataFields {

	private String testcaseName;
	private String UserName;
	private String Password;
	private String email;
	
	public String getTestcaseName() {
		return testcaseName;
	}
	public void setTestcaseName(String testcaseName) {
		this.testcaseName = testcaseName;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "TestDataFields [testcaseName=" + testcaseName + ", UserName=" + UserName + ", Password=" + Password
				+ ", email=" + email + "]";
	}
}