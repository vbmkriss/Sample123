package com.xyz.tests.flipkart.tests;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.xyz.driver.DriverPage;
import com.xyz.extentreports.ExtentManager;
import com.xyz.extentreports.MyExtentReport;
import com.xyz.seleniumapi.SeleniumFunctions;
import com.xyz.tests.dataobjects.FlipkartTestDataFields;
import com.xyz.tests.dataobjects.ReadTestDataStoreInList;
import com.xyz.tests.flipkart.pages.FlipkartSearchPage;
import com.xyz.updateresult.ExcelInputSheetUpdate;
import com.xyz.utils.AppConfigPropertyUtils;
import com.xyz.utils.BrowserVersion;
import com.xyz.utils.EnvironmentPropertyUtils;

public class TestFlipkartProductSearch2 {

	private Logger logger = Logger.getLogger(TestFlipkartProductSearch2.class);

	WebDriver driver;

	FlipkartSearchPage objFlipkartSearchPage;

	int errorFlag = 0;

	ExtentManager extentManager = new ExtentManager();

	MyExtentReport myExtentTest = null;

	String reportPath = "";
	
	String reportName = "";
	
	String osDetails = "";
	
	String browserSetails = "";
	
	String exceptionLog = "";
	
	String browserType = "";
	
	String browserVersion = "";

	@Test(priority=0)
	@Parameters({ "executionID", "appID", "appName", "testcaseId", "testcaseName", "testcaseDescription", "executionFlag", "result", "rerunFlag" })
	public void test_TestFlipkartSearch2(String executionID, String appID, String appName, String testcaseID, String testcaseName, String testcaseDescription, String executionFlag, String result, String rerunFlag) {

		String datasourceType = null;

		String testDataFolderPath = "";

		ArrayList<FlipkartTestDataFields> data = null;

		try {

			browserType = AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionID), "BROWSER_TYPE");

			datasourceType = AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionID), "DATASOURCE_TYPE");

			reportPath = AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionID), "REPORT_PATH");

			testDataFolderPath = AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionID), "TESTDATA_PATH");

			logger.info("reportPath:" + reportPath);
			logger.info("testDataFolderPath:" + testDataFolderPath);

			boolean remoteExecFlag = Boolean.parseBoolean(AppConfigPropertyUtils.getPropertyValueFromConfig(Integer.parseInt(executionID), "REMOTEEXECUTIONFLAG"));

			ReadTestDataStoreInList readTestDataStoreInList = new ReadTestDataStoreInList();

			if(datasourceType.equalsIgnoreCase("excel")) {

				data = readTestDataStoreInList.getFlipkartAppDataAsList(new File(testDataFolderPath + File.separator + "Excel" + File.separator + "TestData.xlsx"), appName, this.getClass().getSimpleName());

			}

			Date myDate = new Date();
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy_HH-mm-ss");  
			System.out.println(formatter.format(myDate));  
			
			int iterationNumber = 0;

			reportName = "reports_"+formatter.format(myDate);

			if(Boolean.parseBoolean(rerunFlag)) {

				reportName = "reports_rerun_"+formatter.format(myDate);

			}

			for(int i = 0; i <data.size(); i++) {

				try {

					iterationNumber = i+1;

					logger.info("Iteration No:" + iterationNumber);

					myExtentTest = extentManager.startReport(reportPath, executionID, appName, testcaseID, iterationNumber, rerunFlag, reportName, testcaseName, testcaseDescription, errorFlag);

					myExtentTest.log(Status.INFO, "=========== Iteration Starts ===========" + iterationNumber);

					myExtentTest.log(Status.INFO, "=========== ENV ===========" + EnvironmentPropertyUtils.envProp.getProperty("ENV"));

					if(browserType.length() ==0 || browserType != null) {
						
						browserType = data.get(i).getBrowserName();
						
						logger.info("browserType browserType:" + browserType);
						
					}

					driver = DriverPage.getDriver(browserType, remoteExecFlag);
					
					browserVersion = BrowserVersion.getBrowserAndVersion(driver);
					
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

					driver.get("https://www.flipkart.com/");

					Thread.sleep(10000);

					System.out.println("****************====**");

					//Create Login Page object
					objFlipkartSearchPage = new FlipkartSearchPage(driver, myExtentTest);

					objFlipkartSearchPage.flipkartMobileSearchByOEM(data.get(i).getProductName());

					String path = SeleniumFunctions.captureScreenshot(driver, reportPath, executionID, appName, this.getClass().getSimpleName(), String.valueOf(iterationNumber));

					logger.info("path:" + path);

					myExtentTest.log(Status.INFO, "Searched Page Loaded successfully", MediaEntityBuilder.createScreenCaptureFromPath(path).build());

				} catch(Exception e) {

					errorFlag = errorFlag + 1;
					extentManager.getException(myExtentTest, e);

				} finally {

					myExtentTest.log(Status.INFO, "=========== Iteration Ends ===========" + iterationNumber);

					try{
						if(driver != null){
							driver.quit();
						}

					} catch(Exception e){

						e.printStackTrace();

					}

				}

			}
		} catch(Exception e) {

			errorFlag = errorFlag + 1;
			
			exceptionLog = extentManager.getException(myExtentTest, e);

		} finally {

			logger.info("errorFlag:" + errorFlag);

			//update the test case status
			if(datasourceType.equalsIgnoreCase("excel")) {

				//ExcelInputSheetUpdate.updateExcel(new File(reportPath + File.separator + "Excel" + File.separator + "Testcases.xlsx"), "testcases" , testcaseName, errorFlag);

				ExcelInputSheetUpdate.updateExcel(new File(reportPath + File.separator + "Excel" + File.separator + "Testcases.xlsx"), "testcases" , testcaseName, errorFlag, "Error Reason", exceptionLog, browserType, browserVersion, extentManager.getReportIterationPath() + File.separator + reportName + ".html");
				
			}
		}

	}

}