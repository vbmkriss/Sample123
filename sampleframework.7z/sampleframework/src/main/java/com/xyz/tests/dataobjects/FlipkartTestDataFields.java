package com.xyz.tests.dataobjects;

public class FlipkartTestDataFields {

	private String testcaseName;
	private String productName;
	private String browserName;
	
	public String getTestcaseName() {
		return testcaseName;
	}
	public void setTestcaseName(String testcaseName) {
		this.testcaseName = testcaseName;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getBrowserName() {
		return browserName;
	}
	public void setBrowserName(String browserName) {
		this.browserName = browserName;
	}
	@Override
	public String toString() {
		return "FlipkartTestDataFields [testcaseName=" + testcaseName + ", productName=" + productName
				+ ", browserName=" + browserName + "]";
	}
}