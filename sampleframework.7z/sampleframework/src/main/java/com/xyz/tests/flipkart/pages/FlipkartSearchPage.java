package com.xyz.tests.flipkart.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.xyz.extentreports.MyExtentReport;
import com.xyz.seleniumapi.SeleniumFunctions;

public class FlipkartSearchPage {

	WebDriver driver;
	
	MyExtentReport extentTest;

	By popupWindow = By.xpath("//*[@class='_2AkmmA _29YdH8']");

	By electronicsLink = By.xpath("//*[text()='Electronics']");

	By realMeMobile = By.xpath("//a[@title='Realme']");

	By samsungMobile = By.xpath("//a[@title='Samsung']");

	public FlipkartSearchPage(WebDriver driver, MyExtentReport extentTest) {

		this.driver = driver;
		
		this.extentTest = extentTest;

	}

	private void clickPopupWindow() {

		List<WebElement> popupWindows = driver.findElements(popupWindow);

		if(popupWindows.size() > 0) {
			popupWindows.get(0).click();
		}

	}

	private void clickRealMe() throws Exception {

		WebElement electronicsTab = driver.findElement(electronicsLink);

		SeleniumFunctions.Hover(driver, electronicsTab);

		Thread.sleep(10000);

		SeleniumFunctions.click(driver, realMeMobile, extentTest);
		
		//realMe.click();

		Thread.sleep(10000);

	}

	private void clickSamsung() throws Exception {

		WebElement electronicsTab = driver.findElement(electronicsLink);

		WebElement samsung = driver.findElement(samsungMobile);

		SeleniumFunctions.Hover(driver, electronicsTab);

		Thread.sleep(10000);

		samsung.click();

		Thread.sleep(10000);

	}

	public void flipkartMobileSearchByOEM(String oemName) throws Exception{

		clickPopupWindow();

		if(oemName.equalsIgnoreCase("realme")) {

			clickRealMe();

		} else if(oemName.equalsIgnoreCase("samsung")) {

			clickSamsung();

		}
	}
}