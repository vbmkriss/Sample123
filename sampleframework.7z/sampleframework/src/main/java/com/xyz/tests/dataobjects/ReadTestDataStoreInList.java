package com.xyz.tests.dataobjects;

import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.xyz.exception.InvalidFileFormatException;
import com.xyz.utils.CommonUtils;

public class ReadTestDataStoreInList {

	public ArrayList<DemoSiteLoginTestDataFields> getDemositeloginAppDataAsList(File file, String sheetName, String testcaseName) throws FilloException, InvalidFileFormatException, SQLException, ClassNotFoundException {

		String fileExtention = CommonUtils.getExtensionOfFile(file);

		ArrayList<DemoSiteLoginTestDataFields> orderTestDataList;

		if(fileExtention.equalsIgnoreCase("xls") || fileExtention.equalsIgnoreCase("xlsx")) {

			orderTestDataList = new ArrayList<>();

			//Now you can set table start row and column
			System.setProperty("ROW", "1");

			Fillo fillo=new Fillo();

			Connection connection = fillo.getConnection(file.getPath());

			String strQuery="Select * from " + sheetName + " where TestcaseName='" + testcaseName + "'";

			Recordset recordset=connection.executeQuery(strQuery);

			while(recordset.next()){

				DemoSiteLoginTestDataFields testData = new DemoSiteLoginTestDataFields();

				System.out.println(recordset.getField("UserName"));

				testData.setTestcaseName(recordset.getField("TestcaseName"));
				testData.setUserName(recordset.getField("UserName"));
				testData.setPassword(recordset.getField("Password"));
				testData.setEmail(recordset.getField("email"));

				orderTestDataList.add(testData);
			}

			recordset.close();
			connection.close();

			Iterator<DemoSiteLoginTestDataFields> it = orderTestDataList.iterator(); 

			while (it.hasNext()) { 
				System.out.println(it.next() + " ");
			}

			return orderTestDataList;

		} else {

			throw new InvalidFileFormatException("File format incorrect:" + fileExtention);
		}
	}

	public ArrayList<RedbusTestDataFields> getRedbusAppDataAsList(File file, String sheetName, String testcaseName) throws FilloException, InvalidFileFormatException, SQLException, ClassNotFoundException {

		String fileExtention = CommonUtils.getExtensionOfFile(file);

		ArrayList<RedbusTestDataFields> orderTestDataList;

		if(fileExtention.equalsIgnoreCase("xls") || fileExtention.equalsIgnoreCase("xlsx")) {

			orderTestDataList = new ArrayList<>();

			//Now you can set table start row and column
			System.setProperty("ROW", "1");

			Fillo fillo=new Fillo();

			Connection connection = fillo.getConnection(file.getPath());

			String strQuery="Select * from " + sheetName + " where TestcaseName='" + testcaseName + "'";

			Recordset recordset=connection.executeQuery(strQuery);

			while(recordset.next()){

				RedbusTestDataFields testData = new RedbusTestDataFields();

				testData.setTestcaseName(recordset.getField("TestcaseName"));
				testData.setFromCity(recordset.getField("FromCity"));
				testData.setToCity(recordset.getField("ToCity"));

				orderTestDataList.add(testData);
			}

			recordset.close();
			connection.close();

			Iterator<RedbusTestDataFields> it = orderTestDataList.iterator(); 

			while (it.hasNext()) { 
				System.out.println(it.next() + " ");
			}

			return orderTestDataList;

		} else {

			throw new InvalidFileFormatException("File format incorrect:" + fileExtention);
		}
	}

	public ArrayList<FlipkartTestDataFields> getFlipkartAppDataAsList(File file, String sheetName, String testcaseName) throws FilloException, InvalidFileFormatException, SQLException, ClassNotFoundException {

		String fileExtention = CommonUtils.getExtensionOfFile(file);

		ArrayList<FlipkartTestDataFields> orderTestDataList;

		if(fileExtention.equalsIgnoreCase("xls") || fileExtention.equalsIgnoreCase("xlsx")) {

			orderTestDataList = new ArrayList<>();

			//Now you can set table start row and column
			System.setProperty("ROW", "1");

			Fillo fillo=new Fillo();

			Connection connection = fillo.getConnection(file.getPath());

			String strQuery="Select * from " + sheetName + " where TestcaseName='" + testcaseName + "'";

			Recordset recordset=connection.executeQuery(strQuery);

			while(recordset.next()){

				FlipkartTestDataFields testData = new FlipkartTestDataFields();

				testData.setTestcaseName(recordset.getField("TestcaseName"));
				testData.setProductName(recordset.getField("ProductName"));
				testData.setBrowserName(recordset.getField("BrowserName"));

				orderTestDataList.add(testData);
			}

			recordset.close();
			connection.close();

			Iterator<FlipkartTestDataFields> it = orderTestDataList.iterator(); 

			while (it.hasNext()) { 
				System.out.println(it.next() + " ");
			}

			return orderTestDataList;

		} else {

			throw new InvalidFileFormatException("File format incorrect:" + fileExtention);
		}
	}
}