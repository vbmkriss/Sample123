package com.xyz.testng;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.xyz.dataobjects.BasicTestcaseInputForm;
import com.xyz.dataobjects.TestCasesExecutionRequestForm;
import com.xyz.dataobjects.TestSuiteExecutionRequestForm;
import com.xyz.utils.AppConfigPropertyUtils;
import com.xyz.utils.CommonUtils;

public class TestNGUtils {

	private static Logger logger = Logger.getLogger(TestNGUtils.class);
	
	private static final String COMMONSUITENAME = "Suite";

	private static int currentGeneratorSequence = 0;

	private static final DateFormat df = new SimpleDateFormat("yyyy_MM_dd_hh_mm_ss");

	String packageName = "";

	public static TestSuiteExecutionRequestForm getSuite(List<BasicTestcaseInputForm> inputs, int executionId) throws IOException {

		logger.info("getSuite:");
		
		//Read the package Name from Config
		Properties configProp = new Properties();

		configProp = CommonUtils.getProperty("/config.properties");

		String packageName = configProp.getProperty("PACKAGENAME");

		TestSuiteExecutionRequestForm suite = new TestSuiteExecutionRequestForm();

		suite.setSuiteName(generateSuiteName());

		List<TestCasesExecutionRequestForm> testCases = new ArrayList<TestCasesExecutionRequestForm>();

		for(BasicTestcaseInputForm input : inputs) {

			input.setExecutionID(executionId);
			input.setRerunFlag("false");

			if(input.getExecutionFlag().equalsIgnoreCase("y")) {
				TestCasesExecutionRequestForm testcase = new TestCasesExecutionRequestForm();
				testcase.getTestClasses().add(packageName + input.getAppName() + ".tests." +input.getTestcaseName());
				testcase.setParameters(CommonUtils.getObjectToMap(input));
				testcase.setTestName(input.getTestcaseName());
				testCases.add(testcase);
			}
		}

		suite.setTestCases(testCases);

		return suite;
	}

	public static TestSuiteExecutionRequestForm rerunGetSuite(List<BasicTestcaseInputForm> inputs, int executionId) throws IOException {

		String rerunFlag = "";

		//Read the package Name from Config
		Properties configProp = new Properties();

		configProp = CommonUtils.getProperty("/config.properties");

		String packageName = configProp.getProperty("PACKAGENAME");

		rerunFlag = AppConfigPropertyUtils.getPropertyValueFromConfig(executionId, "RERUNFLAG");

		TestSuiteExecutionRequestForm suite = new TestSuiteExecutionRequestForm();

		suite.setSuiteName(generateSuiteName());

		List<TestCasesExecutionRequestForm> testCases = new ArrayList<TestCasesExecutionRequestForm>();

		for(BasicTestcaseInputForm input : inputs) {

			input.setExecutionID(executionId);
			input.setRerunFlag(rerunFlag);

			if(input.getExecutionFlag().equalsIgnoreCase("y") && input.getResult().equalsIgnoreCase("fail")) {
				TestCasesExecutionRequestForm testcase = new TestCasesExecutionRequestForm();
				testcase.getTestClasses().add(packageName + input.getAppName() + ".tests." +input.getTestcaseName());
				testcase.setParameters(CommonUtils.getObjectToMap(input));
				testcase.setTestName(input.getTestcaseName());
				testCases.add(testcase);
			}
		}

		suite.setTestCases(testCases);

		return suite;
	}

	public static void generateTestNGxml(List<BasicTestcaseInputForm> inputs, String filePath, int executionId) throws Exception{

		TestSuiteExecutionRequestForm suite = getSuite(inputs, executionId);

		//Get the Thread Count from Config
		String threadCount = AppConfigPropertyUtils.getPropertyValueFromConfig(executionId, "THREADCOUNT");
		suite.setThreadPoolSize(Integer.parseInt(threadCount));

		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dbBuilder = dbFactory.newDocumentBuilder();
		Document doc = dbBuilder.newDocument();
		Element rootElement = doc.createElement("suite");
		doc.appendChild(rootElement);

		Attr rootNameAttribute = doc.createAttribute("name");
		rootNameAttribute.setValue(suite.getSuiteName());

		/*Attr rootParallelAttribute = doc.createAttribute("parallel");
	            rootParallelAttribute.setValue("none");*/

		Attr rootParallelAttribute = doc.createAttribute("parallel");
		rootParallelAttribute.setValue(suite.getParallel());

		Attr rootParallelAttributeThread = doc.createAttribute("thread-count");
		rootParallelAttributeThread.setValue(String.valueOf(suite.getThreadPoolSize()));

		rootElement.setAttributeNode(rootNameAttribute);
		rootElement.setAttributeNode(rootParallelAttribute);
		rootElement.setAttributeNode(rootParallelAttributeThread);

		for(TestCasesExecutionRequestForm testcases : suite.getTestCases()) {

			Element testElement = doc.createElement("test");
			rootElement.appendChild(testElement);

			Attr testNameAttribute = doc.createAttribute("name");
			testNameAttribute.setValue(testcases.getTestName());
			testElement.setAttributeNode(testNameAttribute);

			Element classesElement = doc.createElement("classes");
			testElement.appendChild(classesElement);

			for(String testclass : testcases.getTestClasses()) {

				Element classElement = doc.createElement("class");  
				Attr classNameAttribute = doc.createAttribute("name");
				classNameAttribute.setValue(testclass);
				classElement.setAttributeNode(classNameAttribute);
				classesElement.appendChild(classElement);

			}

			for(Map.Entry<String, String> map: testcases.getParameters().entrySet()) {

				Element paramaterElement = doc.createElement("parameter");  

				Attr paramNameAttribute1 = doc.createAttribute("name");
				paramNameAttribute1.setValue(map.getKey());

				Attr paramNameAttribute2 = doc.createAttribute("value");
				paramNameAttribute2.setValue(map.getValue());

				paramaterElement.setAttributeNode(paramNameAttribute1);
				paramaterElement.setAttributeNode(paramNameAttribute2);

				testElement.appendChild(paramaterElement);
			}

		}

		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File(filePath));
		transformer.transform(source, result);
		// Output to console for testing
		StreamResult consoleResult = new StreamResult(System.out);
		transformer.transform(source, consoleResult);

	}

	public static void generateReunTestNGxml(List<BasicTestcaseInputForm> inputs, String filePath, int executionId) throws Exception{

		TestSuiteExecutionRequestForm suite = rerunGetSuite(inputs, executionId);

		//Get the Thread Count from Config
		String threadCount = AppConfigPropertyUtils.getPropertyValueFromConfig(executionId, "THREADCOUNT");
		suite.setThreadPoolSize(Integer.parseInt(threadCount));

		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dbBuilder = dbFactory.newDocumentBuilder();
		Document doc = dbBuilder.newDocument();
		Element rootElement = doc.createElement("suite");
		doc.appendChild(rootElement);

		Attr rootNameAttribute = doc.createAttribute("name");
		rootNameAttribute.setValue(suite.getSuiteName());

		/*Attr rootParallelAttribute = doc.createAttribute("parallel");
	    rootParallelAttribute.setValue("none");*/

		Attr rootParallelAttribute = doc.createAttribute("parallel");
		rootParallelAttribute.setValue(suite.getParallel());

		Attr rootParallelAttributeThread = doc.createAttribute("thread-count");
		rootParallelAttributeThread.setValue(String.valueOf(suite.getThreadPoolSize()));

		rootElement.setAttributeNode(rootNameAttribute);
		rootElement.setAttributeNode(rootParallelAttribute);
		rootElement.setAttributeNode(rootParallelAttributeThread);

		for(TestCasesExecutionRequestForm testcases : suite.getTestCases()) {

			Element testElement = doc.createElement("test");
			rootElement.appendChild(testElement);

			Attr testNameAttribute = doc.createAttribute("name");
			testNameAttribute.setValue(testcases.getTestName());
			testElement.setAttributeNode(testNameAttribute);

			Element classesElement = doc.createElement("classes");
			testElement.appendChild(classesElement);

			for(String testclass : testcases.getTestClasses()) {

				Element classElement = doc.createElement("class");  
				Attr classNameAttribute = doc.createAttribute("name");
				classNameAttribute.setValue(testclass);
				classElement.setAttributeNode(classNameAttribute);
				classesElement.appendChild(classElement);

			}

			for(Map.Entry<String, String> map: testcases.getParameters().entrySet()) {

				Element paramaterElement = doc.createElement("parameter");  

				Attr paramNameAttribute1 = doc.createAttribute("name");
				paramNameAttribute1.setValue(map.getKey());

				Attr paramNameAttribute2 = doc.createAttribute("value");
				paramNameAttribute2.setValue(map.getValue());

				paramaterElement.setAttributeNode(paramNameAttribute1);
				paramaterElement.setAttributeNode(paramNameAttribute2);

				testElement.appendChild(paramaterElement);
			}

		}

		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File(filePath));
		transformer.transform(source, result);
		// Output to console for testing
		StreamResult consoleResult = new StreamResult(System.out);
		transformer.transform(source, consoleResult);

	}

	public static synchronized String generateSuiteName() {

		String suiteName = COMMONSUITENAME + "_" + currentGeneratorSequence + df.format(new Date());
		currentGeneratorSequence++;

		return suiteName;

	}
}