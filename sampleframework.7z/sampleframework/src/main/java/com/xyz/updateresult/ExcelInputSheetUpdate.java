package com.xyz.updateresult;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

public class ExcelInputSheetUpdate {

	private static Logger logger = Logger.getLogger(ExcelInputSheetUpdate.class);

	public static void updateExcel(File file, String sheetName, String testcaseName, int errorFlag){

		String strQuery;
		Connection connection = null;

		try {

			Fillo fillo=new Fillo();

			connection=fillo.getConnection(file.getPath());

			if(errorFlag > 0) {

				strQuery="Update "+  sheetName + " Set Result='Fail' where TestcaseName='" + testcaseName + "'";

			} else {

				strQuery="Update "+  sheetName + " Set Result='Pass' where TestcaseName='" + testcaseName + "'";

			}

			logger.info("=====strQuery=====" + strQuery);

			connection.executeUpdate(strQuery);

		} catch(Exception e) {

			e.printStackTrace();

		} finally {

			connection.close();

		}
	}

	public synchronized static void updateExcel(File file, String sheetName, String testcaseName, int errorFlag, String failureReason, String errorLog, String browserName, String browserVersion, String reportUrl){

		String strQuery;

		Connection connection = null;

		try {

			Fillo fillo=new Fillo();

			connection=fillo.getConnection(file.getPath());

			if(errorFlag > 0) {

				strQuery="Update "+  sheetName + " Set Result='Fail'," 
						+ "FailureReason='"+failureReason   + "',"
						+ "Errorlog='"+errorLog + "',"
						+ "BrowserName='"+browserName  + "',"
						+ "BrowserVersion='"+browserVersion  + "',"
						+ "ReportLink='"+reportUrl  + "'"
						+ " where TestcaseName='" + testcaseName + "'";

			} else {

				strQuery="Update "+  sheetName + " Set Result='Pass'," 
						+ "FailureReason='"+failureReason   + "',"
						+ "Errorlog='"+errorLog + "',"
						+ "BrowserName='"+browserName  + "',"
						+ "BrowserVersion='"+browserVersion  + "',"
						+ "ReportLink='"+reportUrl  + "'"
						+ " where TestcaseName='" + testcaseName + "'";

			}

			logger.info("=====strQuery=====" + strQuery);

			connection.executeUpdate(strQuery);

		} catch(Exception e) {

			e.printStackTrace();

		} finally {

			connection.close();

		}
	}

	public synchronized static void createAndUpdateResultExcel(File file){

		String strQuery;
		
		String sheetName = "testcases";

		Connection connection = null;

		try {
			
			logger.info("filefile:" + file);
			
			File myFile = file;

			// Now get the path
			/*String myDir = myFile.getParent();
			logger.info("myDir:" + myDir);*/

			File dest = new File(myFile +  File.separator + "Excel" + File.separator + "Results.xlsx");
			FileUtils.copyFile(new File(file +  File.separator + "Excel" + File.separator + "Testcases.xlsx"), dest);

			Fillo fillo=new Fillo();

			connection=fillo.getConnection(dest.getPath());

			strQuery="select * from "+  sheetName;

			logger.info("=====strQuery=====" + strQuery);

			Recordset recordSet = connection.executeQuery(strQuery);

			int rowPos = 1;
			
			logger.info("=====recordSet.getCount()=====" + recordSet.getCount());
			
			ArrayList<Integer> list = new ArrayList<Integer>();    
			
			while (recordSet.next()) {
				
				rowPos = rowPos+1;
				
				if(recordSet.getField("ExecutionFlag").equalsIgnoreCase("n")){
					
					list.add(rowPos);
					
				}

			}
			
			for (int i = list.size()-1; i >=0 ; i--) {
				logger.info(list.get(i));
				deleteRowInExcel(dest.getPath(), list.get(i));
			}
			
		} catch(Exception e) {

			e.printStackTrace();

		} finally {

			connection.close();

		}
	}

	public static void deleteRowInExcel(String fileName, int rowIndex) throws IOException, InvalidFormatException, FileNotFoundException {
		
		Workbook workbook = WorkbookFactory.create(new FileInputStream(fileName));

		Sheet worksheet = workbook.getSheetAt(0);

		int rowCount = (worksheet.getLastRowNum())+1;
		
		logger.info("worksheet.getLastRowNum()::" + rowCount);
		worksheet.shiftRows(rowIndex, worksheet.getLastRowNum()+1, -1);

		workbook.write(new FileOutputStream(fileName));
		workbook.close();
	}
	
	public static void main(String args[]) throws IOException {

		updateExcel(new File("D:\\Murali\\ABCD\\Reports\\Excel\\Testcases.xlsx"), "testcases","TestFlipkartProductSearch1", 0, "Reason", "Logs", "Chrome", "1.11","ReportURLLL");
		createAndUpdateResultExcel(new File("D:\\Murali\\ABCD\\Reports\\Excel\\Testcases.xlsx"));
	}
}