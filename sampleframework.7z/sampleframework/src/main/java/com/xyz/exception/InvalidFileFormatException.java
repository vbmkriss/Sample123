package com.xyz.exception;

public class InvalidFileFormatException extends Exception{

	private static final long serialVersionUID = 1L;

	public InvalidFileFormatException(String msg) {
		super("InvalidFileFormatException:"+msg);
	}


	public InvalidFileFormatException(Exception exception) {
		super("InvalidFileFormatException:"+exception);
	}

}