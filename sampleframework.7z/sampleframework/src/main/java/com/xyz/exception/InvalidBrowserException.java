package com.xyz.exception;

public class InvalidBrowserException extends Exception{

	private static final long serialVersionUID = 1L;

	public InvalidBrowserException(String msg) {
		super("InvalidBrowserException:"+msg);
	}


	public InvalidBrowserException(Exception exception) {
		super("InvalidBrowserException:"+exception);
	}

}