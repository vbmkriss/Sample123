package com.xyz.exception;

public class MandatoryParamaterMissingException extends Exception{

	private static final long serialVersionUID = 1L;

	public MandatoryParamaterMissingException(String msg) {
		super("MandatoryParamaterMissingException:"+msg + System.lineSeparator() + 
				"Sample: -DExecutionId=125[M] -DEnvironmentName=PROD[M] -DDatasourceType=excel -DBrowserName=CHROME -DReportPath=D:\\Murali\\ABCD\\[M] -DTestDataInputPath=D:\\Murali\\ABCD\\[M] -DRemoteExecutionFlag=false -DRerunFlag=false -DThreadCount=1 -D=false");
	}


	public MandatoryParamaterMissingException(Exception exception) {
		super("MandatoryParamaterMissingException:"+exception);
	}

}